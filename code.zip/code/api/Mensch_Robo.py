# mensch_robo_tab.py
import os
from pathlib import Path
import random

from PyQt6.QtWidgets import (
    QWidget, QLabel, QListWidget, QListWidgetItem,
    QHBoxLayout, QVBoxLayout, QFrame, QPushButton
)
from PyQt6.QtCore import QSize, QBuffer, QByteArray, QIODevice, Qt, QMimeData
from PyQt6.QtGui import QPixmap, QDrag, QImage

# -------- Theme: same as other widgets --------
THEME_CSS = """
QWidget {
    background-color: #f7f8fc;
    color: #0f172a;
    font-family: "Segoe UI", "Inter", "SF Pro Text", Arial, sans-serif;
    font-size: 13px;
}
/* Section headers */
QFrame#SectionHeader {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                stop:0 #2563eb, stop:1 #ec4899);
    border-radius: 12px;
}
#SectionHeaderTitle {
    color: #0f172a;   /* black */
    font-size: 14px;
    font-weight: 700;
    background: transparent;
}

/* White card containers (center canvas) */
QFrame[role="card"] {
    background: white;
    border: 1px solid #e5e7eb;
    border-radius: 12px;
}

/* Blue panels for pics & descriptions columns */
QFrame[role="card-blue"] {
    background: #2563eb;
    border: 1px solid #1e40af;
    border-radius: 12px;
}

/* Buttons: blue→pink gradient */
QPushButton {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                stop:0 #2563eb, stop:1 #ec4899);
    color: white;
    border: none;
    border-radius: 10px;
    padding: 8px 14px;
    font-weight: 700;
}
QPushButton:hover {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                stop:0 #3b82f6, stop:1 #f472b6);
}
QPushButton:pressed {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                stop:0 #1e40af, stop:1 #be185d);
}

/* Lists */
QListWidget {
    background: transparent;
    border: none;
}
"""

def make_section_header(text: str) -> QFrame:
    """Gradient blue→pink header bar with black title."""
    frame = QFrame()
    frame.setObjectName("SectionHeader")
    layout = QHBoxLayout(frame)
    layout.setContentsMargins(12, 8, 12, 8)
    title = QLabel(text)
    title.setObjectName("SectionHeaderTitle")
    layout.addWidget(title)
    layout.addStretch(1)
    return frame

# Expected parts in top-to-bottom order for the left drop zones
EXPECTED_PART_ORDER = [
    "ESP32 Mikrocontroller",
    "AS5600 Encoder",
    "BLDC Gimbal Motor",
    "SimpleFOC Mini",
]


class DraggableList(QListWidget):
    def __init__(self, items, image_paths=None):
        super().__init__()
        self.setDragEnabled(True)

        if image_paths is not None:
            # Left column: parts with image + name
            for item_text in items:
                image_path = image_paths.get(item_text, None)

                pixmap = QPixmap(image_path) if image_path and os.path.exists(image_path) else QPixmap()
                if pixmap.isNull():
                    print(f"[WARNUNG] Bild ungültig oder fehlt: {image_path}")
                    pixmap = QPixmap(120, 120)
                    pixmap.fill(Qt.GlobalColor.gray)

                scaled = pixmap.scaled(100, 100, Qt.AspectRatioMode.KeepAspectRatio)

                img_label = QLabel()
                img_label.setPixmap(scaled)
                img_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

                text_label = QLabel(item_text)
                text_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
                text_label.setStyleSheet("font-size: 13px; font-weight: bold; color: #0f172a;")

                widget = QWidget()
                vbox = QVBoxLayout(widget)
                vbox.addWidget(img_label)
                vbox.addWidget(text_label)
                vbox.setAlignment(Qt.AlignmentFlag.AlignCenter)
                vbox.setContentsMargins(6, 6, 6, 6)
                widget.setStyleSheet("""
                    QWidget {
                        background: white;
                        border: 1px solid #e5e7eb;
                        border-radius: 10px;
                    }
                """)

                item = QListWidgetItem()
                item.setSizeHint(widget.sizeHint())

                self.addItem(item)
                self.setItemWidget(item, widget)

        else:
            # Right column: text-only descriptions
            for item_text in items:
                text_label = QLabel(item_text)
                text_label.setWordWrap(True)
                text_label.setAlignment(Qt.AlignmentFlag.AlignLeft)
                text_label.setStyleSheet("""
                    font-size: 13px;
                    color: #0f172a;
                    padding: 8px;
                    border: 1px solid #e5e7eb;
                    border-radius: 10px;
                    background-color: white;
                """)

                font_metrics = text_label.fontMetrics()
                text_height = font_metrics.boundingRect(
                    0, 0, 230, 0, Qt.TextFlag.TextWordWrap, item_text
                ).height()

                widget = QWidget()
                vbox = QVBoxLayout(widget)
                vbox.addWidget(text_label)
                vbox.setContentsMargins(6, 6, 6, 6)

                item = QListWidgetItem()
                item.setSizeHint(QSize(230, text_height + 50))

                self.addItem(item)
                self.setItemWidget(item, widget)

        self.setStyleSheet("QListWidget { background: transparent; }")

    def startDrag(self, supportedActions):
        item = self.currentItem()
        if not item:
            return

        drag = QDrag(self)
        mime_data = QMimeData()

        widget = self.itemWidget(item)
        labels = widget.findChildren(QLabel)

        if len(labels) == 2:
            img_label = labels[0]
            text_label = labels[1]
        elif len(labels) == 1:
            img_label = None
            text_label = labels[0]
        else:
            print(" No valid label widget found")
            return

        name = text_label.text()
        mime_data.setText(name)

        if img_label:
            pixmap = img_label.pixmap()
            if pixmap:
                byte_array = QByteArray()
                buffer = QBuffer(byte_array)
                buffer.open(QBuffer.OpenModeFlag.WriteOnly)
                pixmap.save(buffer, "PNG")
                mime_data.setImageData(byte_array.data())

        drag.setMimeData(mime_data)
        drag.exec()


class DropZoneLabel(QLabel):
    def __init__(self, zone_name=""):
        super().__init__()
        self.setAcceptDrops(True)
        self.setFixedSize(120, 60)
        self.setStyleSheet("""
            background-color: #fff;
            border: 2px dashed #9ca3af;
            color: #333;
            font-weight: bold;
            padding: 5px;
            border-radius: 8px;
        """)
        self.setText(zone_name)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)

    def dragEnterEvent(self, event):
        if event.mimeData().hasText():
            event.acceptProposedAction()

    def dropEvent(self, event):
        self.setText(event.mimeData().text())
        event.acceptProposedAction()


class ImageDropLabel(QLabel):
    """Single, clean version: expects text (part name) + image bytes."""
    def __init__(self, expected_name=""):
        super().__init__()
        self.expected_name = expected_name
        self.setAcceptDrops(True)
        self.setMinimumSize(120, 120)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setStyleSheet("""
            background-color: white;
            border: 2px dashed #9ca3af;
            border-radius: 10px;
        """)

    def dragEnterEvent(self, event):
        if event.mimeData().hasImage() and event.mimeData().hasText():
            event.acceptProposedAction()
        else:
            event.ignore()

    def dropEvent(self, event):
        if event.mimeData().hasImage() and event.mimeData().hasText():
            dragged_name = event.mimeData().text()
            pixmap = QPixmap()
            pixmap.loadFromData(event.mimeData().imageData())

            self.setPixmap(pixmap.scaled(100, 100, Qt.AspectRatioMode.KeepAspectRatio))
            if dragged_name == self.expected_name:
                # correct → soft green
                self.setStyleSheet("background-color: #d1fae5; border: 2px solid #10b981; border-radius: 10px;")
            else:
                # wrong → soft red
                self.setStyleSheet("background-color: #fee2e2; border: 2px solid #ef4444; border-radius: 10px;")

            event.acceptProposedAction()


class TextDropLabel(QLabel):
    def __init__(self, expected_text=None):
        super().__init__()
        self.setAcceptDrops(True)
        # normalize the expected text once
        self.expected_text = (expected_text or "").strip()
        self.setMinimumSize(120, 120)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setWordWrap(True)
        self.setStyleSheet("background-color: white; border: 2px dashed #9ca3af; border-radius: 10px;")

    def dragEnterEvent(self, event):
        if event.mimeData().hasText():
            event.acceptProposedAction()
        else:
            event.ignore()

    def dropEvent(self, event):
        if event.mimeData().hasText():
            # normalize dropped text the same way
            got = (event.mimeData().text() or "").strip()

            if got.casefold() == self.expected_text.casefold():
                self.setStyleSheet("background-color: #d1fae5; border: 2px solid #10b981; border-radius: 10px;")
                self.setText(got)
            else:
                self.setStyleSheet("background-color: #fee2e2; border: 2px solid #ef4444; border-radius: 10px;")
                self.setText(got)

            event.accept()



def get_expected_image_for(body_part):
    image_to_bodypart = {
        "ESP32 Mikrocontroller": "Kopf",
        "AS5600 Encoder": "Auge",
        "BLDC Gimbal Motor": "Arm",
        "SimpleFOC Mini": "Rumpf"
    }
    for image, target in image_to_bodypart.items():
        if target == body_part:
            return image
    return None


class RobotCanvas(QWidget):
    def __init__(self, image_path, part_names=None, part_descriptions=None, body_labels=None, part_image_paths=None):
        super().__init__()

        self.part_names = part_names or []
        self.part_descriptions = part_descriptions or []
        self.body_labels = body_labels or []
        self.part_image_paths = part_image_paths or []

        layout = QHBoxLayout(self)

        # Left drop zones — fixed expected order (top → bottom)
        self.left_drop_labels = []
        left_drop_zone_layout = QVBoxLayout()
        for expected_name in EXPECTED_PART_ORDER:
            drop = ImageDropLabel(expected_name=expected_name)
            left_drop_zone_layout.addWidget(drop)
            self.left_drop_labels.append(drop)

        # Center robot image
        center_layout = QVBoxLayout()
        robot_label = QLabel()
        pixmap = QPixmap(image_path)
        if pixmap.isNull():
            pixmap = QPixmap(300, 400)
            pixmap.fill(Qt.GlobalColor.gray)
        robot_label.setPixmap(pixmap.scaled(300, 400, Qt.AspectRatioMode.KeepAspectRatio))
        robot_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        center_layout.addStretch()
        center_layout.addWidget(robot_label)
        center_layout.addStretch()

        # Right drop zones (texts)
        self.right_drop_labels = []
        right_drop_zone_layout = QVBoxLayout()
        for desc in self.part_descriptions:
            drop = TextDropLabel(expected_text=desc)
            right_drop_zone_layout.addWidget(drop)
            self.right_drop_labels.append(drop)

        # Compose three columns
        layout.addLayout(left_drop_zone_layout)
        layout.addLayout(center_layout)
        layout.addLayout(right_drop_zone_layout)

    def reset_drops(self):
        """Clear all drop zones and restore neutral dashed style (no red/green)."""
        neutral = "background-color: white; border: 2px dashed #9ca3af; border-radius: 10px;"

        # Left: image drop zones
        for drop in self.left_drop_labels:
            drop.clear()  # removes any pixmap/text
            drop.setPixmap(QPixmap())  # make sure image is gone
            drop.setText("")  # just in case
            drop.setStyleSheet(neutral)  # remove green/red, back to neutral

        # Right: text drop zones
        for drop in self.right_drop_labels:
            drop.clear()  # removes text
            drop.setText("")
            drop.setStyleSheet(neutral)  # remove green/red, back to neutral


class DropZone(QLabel):
    def __init__(self, title):
        super().__init__()
        self.setAcceptDrops(True)
        self.setText(f"{title}\n(Drop hier)")
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setFixedSize(160, 80)
        self.setWordWrap(True)
        self.setStyleSheet("""
            QLabel {
                background-color: #ffffff;
                border: 2px dashed #9ca3af;
                border-radius: 8px;
                padding: 6px;
                font-size: 12px;
            }
        """)

    def dragEnterEvent(self, event):
        if event.mimeData().hasText():
            event.acceptProposedAction()

    def dropEvent(self, event):
        text = event.mimeData().text()
        self.setText(text)
        event.acceptProposedAction()


class MenschRoboTab(QWidget):
    def __init__(self):
        super().__init__()

        self.setStyleSheet(THEME_CSS)

        self.body_labels = ["Head", "Eye", "Arm", "Torso"]
        self.part_names = ["ESP32 Mikrocontroller", "AS5600 Encoder", "BLDC Gimbal Motor", "SimpleFOC Mini"]

        # --- Base dir setup ---
        BASE_DIR = Path(__file__).resolve().parent
        PICS_DIR = BASE_DIR / "pics"

        def pic_path(name: str) -> str:
            """Return a Qt-friendly image path from the /pics folder."""
            p = PICS_DIR / name
            print(f"[IMG] Expecting: {p}  Exists? {p.exists()}")
            return p.as_posix()

        # --- Image paths ---
        self.part_image_paths = {
            "ESP32 Mikrocontroller": pic_path("microcontroller.png"),
            "AS5600 Encoder": pic_path("encoder.png"),
            "BLDC Gimbal Motor": pic_path("motor.png"),
            "SimpleFOC Mini": pic_path("lucky2.png"),
        }

        self.part_descriptions = [
            "Microcontroller for central control – like the brain.",
            "Sensor for precise angle measurement – like the sense of joint position in the body",
            " Motor for controlled movement – like a muscle.",
            "Motor controller for fine movements – like the spinal cord."
        ]

        IMAGES_DIR = BASE_DIR / "pics"

        self.robot_canvas = RobotCanvas(
            image_path=(IMAGES_DIR / "robohuman.jpg").as_posix(),
            part_names=self.part_names,
            part_descriptions=self.part_descriptions,
            body_labels=self.body_labels,
            part_image_paths=self.part_image_paths
        )

        # Shuffle lists for the draggable items (order of EXPECTED_PART_ORDER stays fixed)
        random.shuffle(self.part_names)
        random.shuffle(self.part_descriptions)

        self.part_list = DraggableList(self.part_names, self.part_image_paths)
        self.part_list.setFixedWidth(220)

        self.description_list = DraggableList(self.part_descriptions)
        self.description_list.setFixedWidth(260)

        # ----- Layout: add gradient section headers + cards -----
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(16, 16, 16, 16)
        main_layout.setSpacing(12)

        top_row = QHBoxLayout()
        top_row.setSpacing(12)

        # Left column (Components) — BLUE panel
        left_col = QVBoxLayout()
        left_col.addWidget(make_section_header("Components"))
        left_card = QFrame()
        left_card.setProperty("role", "card-blue")
        left_card_lay = QVBoxLayout(left_card)
        left_card_lay.setContentsMargins(10, 10, 10, 10)
        left_card_lay.addWidget(self.part_list)
        left_col.addWidget(left_card)

        # Center column (Robot Canvas) — WHITE card
        center_col = QVBoxLayout()
        center_col.addWidget(make_section_header("Robot / Human Canvas"))
        center_card = QFrame()
        center_card.setProperty("role", "card")
        center_card_lay = QVBoxLayout(center_card)
        center_card_lay.setContentsMargins(10, 10, 10, 10)
        center_card_lay.addWidget(self.robot_canvas)
        center_col.addWidget(center_card)

        # Right column (Descriptions) — BLUE panel
        right_col = QVBoxLayout()
        right_col.addWidget(make_section_header("Descriptions"))
        right_card = QFrame()
        right_card.setProperty("role", "card-blue")
        right_card_lay = QVBoxLayout(right_card)
        right_card_lay.setContentsMargins(10, 10, 10, 10)
        right_card_lay.addWidget(self.description_list)
        right_col.addWidget(right_card)

        top_row.addLayout(left_col, 1)
        top_row.addLayout(center_col, 1)
        top_row.addLayout(right_col, 1)

        # Reset Button
        reset_button = QPushButton("Reset")
        reset_button.clicked.connect(self.robot_canvas.reset_drops)

        main_layout.addLayout(top_row)
        main_layout.addWidget(reset_button)

        self.setLayout(main_layout)
