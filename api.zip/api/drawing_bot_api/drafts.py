#!/usr/bin/env python3
from drawing_bot_api import DrawingBot
from drawing_bot_api.shapes import *

# Here you can adjust the speed of the robot and change the unit if you prefer another: meters (m), centimeters (cm), millimeters (mm)
drawing_bot = DrawingBot(unit='mm', speed=200)

#################################
#             DOMAIN            #
#                               #
#  +160    ............         #
#        ..            ..       #
#  +120 .                .      #
#       .                .      #11
#  +70  ..................      #
#      -70             +70      #
#################################

# These are the predefined shapes you can draw and add together:

# Line(starting_point, end_point)
# e.g. Line([-30, 80], [40, 100])

# Circle(center_point, radius)
# e.g. Circle([-10, 110], 20)

# Partial_circle(start_point, end_point, radius, direction) optional: big_angle
# e.g. Partial_circle([-20, 120], [10, 100], 25, -1, big_angle=True)


# EXAMPLE FUNCTIONS:
def heart():
    drawing_bot.add_shape(PartialCircle([0, 135], [-40, 110], 25, 1, big_angle=True))
    drawing_bot.add_shape(Line([-40, 110], [0, 75]))
    drawing_bot.add_shape(Line([0, 75], [40, 110]))
    drawing_bot.add_shape(PartialCircle([40, 110], [0, 135], 25, 1, big_angle=True))

def square(width, center):
    side = width/2
    drawing_bot.add_shape(Line([center[0]-side, center[1]+side], [center[0]+side, center[1]+side]))
    drawing_bot.add_shape(Line([center[0]+side, center[1]+side], [center[0]+side, center[1]-side]))
    drawing_bot.add_shape(Line([center[0]+side, center[1]-side], [center[0]-side, center[1]-side]))
    drawing_bot.add_shape(Line([center[0]-side, center[1]-side], [center[0]-side, center[1]+side]))

# -----------------------
# Extra drawing functions
# -----------------------

def circle():
    drawing_bot.add_shape(Circle([0, 110], 20))

def letter_E(x=0, y=100, s=10):
    drawing_bot.add_shape(Line([x, y + s], [x, y - s]))
    drawing_bot.add_shape(Line([x, y + s], [x + s, y + s]))
    drawing_bot.add_shape(Line([x, y], [x + s * 0.8, y]))
    drawing_bot.add_shape(Line([x, y - s], [x + s, y - s]))

def letter_R(x=0, y=100, s=10):
    drawing_bot.add_shape(Line([x, y - s], [x, y + s]))
    drawing_bot.add_shape(PartialCircle([x, y + s], [x, y], s, -1, big_angle=False))
    drawing_bot.add_shape(Line([x, y], [x + s, y - s]))

def letter_A(x=0, y=100, s=10):
    drawing_bot.add_shape(Line([x - s/2, y - s], [x, y + s]))
    drawing_bot.add_shape(Line([x, y + s], [x + s/2, y - s]))
    drawing_bot.add_shape(Line([x - s/4, y], [x + s/4, y]))

def letter_M(x=0, y=100, s=10):
    drawing_bot.add_shape(Line([x, y - s], [x, y + s]))
    drawing_bot.add_shape(Line([x, y + s], [x + s/2, y]))
    drawing_bot.add_shape(Line([x + s/2, y], [x + s, y + s]))
    drawing_bot.add_shape(Line([x + s, y + s], [x + s, y - s]))

def write_eram():
    spacing = 25
    letter_E(x=-spacing*1.5, y=100, s=10)
    letter_R(x=-spacing*0.5, y=100, s=10)
    letter_A(x=spacing*0.5, y=100, s=10)
    letter_M(x=spacing*1.5, y=100, s=10)

########################################################
# THE FOLLOWING CODE IS THE CODE THAT WILL BE EXECUTED #
########################################################

def main():
    #drawing_bot.hard_reset()

    print("Was möchtest du zeichnen?")
    print("1: Kreis (Circle)")
    print("2: Herz (Heart)")
    print("3: Name 'Eram'")
    choice = input("Deine Wahl: ").strip()

    if choice == '1':
        circle()
    elif choice == '2':
        heart()
    elif choice == '3':
        write_eram()
    else:
        print("Ungültige Eingabe.")
        return

    drawing_bot.plot()
    drawing_bot.execute(promting=True)

main()

